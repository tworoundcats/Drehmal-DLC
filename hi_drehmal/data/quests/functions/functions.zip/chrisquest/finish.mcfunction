execute positioned ~ ~ ~ as @p[tag=qst9] at @s run tellraw @s ["",{"text":"Quest Completed:","color":"yellow"},{"text":" "},{"text":"Lofty Legend","underlined":true},{"text":"\n"},{"text":"Bring Chris a Portable Music Player","italic":true,"color":"gray"}]
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 40
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run playsound minecraft:dcustom.ui.toast.challenge_complete player @a ~ ~ ~ 1 1
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~2 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon experience_orb ~ ~ ~1 {Value:10}
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run summon firework_rocket ~ ~2 ~ {LifeTime:30,FireworksItem:{id:firework_rocket,Count:1,tag:{Fireworks:{Flight:2,Explosions:[{Type:1,Flicker:0b,Trail:0b,Colors:[I;15790320],FadeColors:[I;15790320]}]}}}}
execute positioned ~ ~ ~ as @p[tag=qst9] run advancement grant @s only dlc:chris
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run function dlc:give/merch_voucher
execute at @e[tag=chris] as @a[distance=..20] run journal quest complete @s Chris
execute at @e[tag=chris] as @a[distance=..20] at @s run playsound dlc:writing player @s ~ ~ ~ 1 1
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run give @s dlc:olkahan{Olkahan:1b,display: {Name: '{"extra":[{"italic":false,"underlined":true,"color":"light_purple","text":"Olkahan Ingot"}],"text":""}', Lore: ['{"extra":[{"italic":true,"color":"dark_purple","text":"An immensely rare metal only found"}],"text":""}', '{"extra":[{"italic":true,"color":"dark_purple","text":"on the underside of the Disc. In a "}],"text":""}', '{"extra":[{"italic":true,"color":"dark_purple","text":"post-rehntite era, it may be the single "}],"text":""}', '{"extra":[{"italic":true,"color":"dark_purple","text":"most sought-after mineral in the realm"}],"text":""}', '{"extra":[{"italic":true,"color":"dark_purple","text":"—for those who even know of its existence."}],"text":""}']}} 2
execute as @e[tag=chris] run tag @s add qend
execute positioned ~ ~ ~ as @p[tag=qst9] at @s run tag @s remove qst9

execute unless score #quest9 bool matches 1 run scoreboard players add #quest num 1
execute if score #quest num matches 17 run advancement grant @a only dlc:questmaster
scoreboard players set #quest9 bool 1